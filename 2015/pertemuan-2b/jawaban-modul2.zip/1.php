<?php 
// Pertemuan 1b
// Latihan 1
// Mencetak 2 buah variabel berisi string dan menggabungkannya menggunakan operator concat

$teks1 = "Twinkle";
$teks2 = "star";

echo $teks1 . ", " . $teks1 . " little " . $teks2 . ".";
?>
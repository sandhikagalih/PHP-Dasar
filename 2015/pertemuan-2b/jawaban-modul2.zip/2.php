<?php 
// Pertemuan 1b
// Latihan 2
// melakukan operasi matematika sederhana pada sebuah variabel

$angka = 10;

echo "Aku adalah angka " . $angka . "<br>";
echo "Jika aku ditambah 7. " . "Sekarang aku menjadi " . $angka = $angka+7 . "<br>";
echo "Jika aku dikurang 4. " . "Sekarang aku menjadi " . $angka = $angka-4 . "<br>";
echo "Jika aku dikali 3. " . "Sekarang aku menjadi " . $angka = $angka*3 . "<br>";
echo "Jika aku dibagi 5. " . "Sekarang aku menjadi " . $angka = $angka/5 . "<br>";
?>